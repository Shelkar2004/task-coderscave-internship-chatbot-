from django.shortcuts import render, redirect
from django.http import JsonResponse
import openai
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import auth
from .models import Chat
import google.generativeai as genai
from django.utils import timezone
from django.contrib.auth.decorators import login_required

# Set your OpenAI API key
# openai_api_key = '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'
# openai.api_key = openai_api_key
# Or use `os.getenv('GOOGLE_API_KEY')` to fetch an environment variable.
GOOGLE_API_KEY = "AIzaSyAaM9rG1uuKTrhX2fSDF8T9ktHEvDrPlD4"
genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel('gemini-pro')
# Function to interact with OpenAI and get a response for the user's message
def ask_openai(message):
    try:
        # Request response from OpenAI API
        # response = openai.Completion.create(
        #     model="text-davinci-003",
        #     prompt="You are a helpful assistant.\nUser: " + message,
        #     max_tokens=50  # Adjust max_tokens as needed
        # )
        response = model.generate_content(message)
        
        # Extract the response text from the API response
        # answer = response.choices[0].text.strip()
        
        # Return the response
        # print(answer)
        return response.text
    except Exception as e:
        # Log the error for debugging purposes
        print(f"Error interacting with OpenAI: {e}")
        
        # Provide a fallback response in case of error
        return "I'm sorry, but I couldn't process your request at the moment. Please try again later."

# View function to render the chatbot interface and handle user interaction
# View function to render the chat interface and handle user interaction
def chatbot(request):
    # Check if the user is authenticated
    if not request.user.is_authenticated:
        # Redirect to the login page if not authenticated
        return redirect('login')

    # Retrieve chat history for the current user
    chats = Chat.objects.filter(user=request.user)

    if request.method == 'POST':
        # Get the user's message from the form submission
        message = request.POST.get('message')

        # Save the user's message to the database
        chat = Chat(user=request.user, message=message, created_at=timezone.now())
        chat.save()
        response = ask_openai(message)
        # Return the user's message as JSON
        return JsonResponse({'response': response})
    
    # Render the chat interface with the chat history
    return render(request, 'chatbot.html', {'chats': chats})


def login(request):
    # Check if the user is already authenticated
    if request.user.is_authenticated:
        # Redirect to the chatbot page if already authenticated
        return redirect('chatbot')

    if request.method == 'POST':
        # Retrieve username and password from the login form submission
        username = request.POST['username']
        password = request.POST['password']
        
        # Authenticate user credentials
        user = auth.authenticate(request, username=username, password=password)
        
        if user is not None:
            # If authentication is successful, log the user in and redirect to the chatbot page
            auth.login(request, user)
            return redirect('chatbot')
        else:
            # If authentication fails, render the login page with an error message
            error_message = 'Invalid username or password'
            return render(request, 'login.html', {'error_message': error_message})
    else:
        # Render the login page for GET requests
        return render(request, 'login.html')
    
def register(request):
    if request.method == 'POST':
        # If the request method is POST, it means the user submitted the registration form
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 == password2:
            # If the passwords match, attempt to create a new user
            try:
                user = User.objects.create_user(username, email, password1)
                user.save()
                # Log the user in after successful registration
                auth.login(request, user)
                # Redirect to the chatbot page
                return redirect('chatbot')
            except:
                # If an error occurs during registration, render the registration page again with an error message
                error_message = 'Error creating account'
                return render(request, 'register.html', {'error_message': error_message})
        else:
            # If the passwords don't match, render the registration page again with an error message
            error_message = 'Passwords do not match'
            return render(request, 'register.html', {'error_message': error_message})
    else:
        # If the request method is GET, it means the user is accessing the registration page
        return render(request, 'register.html')

def logout(request):
    # Log the user out by calling auth.logout(request)
    auth.logout(request)
    # Redirect the user to the login page
    return redirect('login')
